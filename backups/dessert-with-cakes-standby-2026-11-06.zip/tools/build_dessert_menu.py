"""Create the approval-only extended dessert menu. Never modifies dist."""
from pathlib import Path
from io import BytesIO
import pymupdf
import arabic_reshaper
from bidi.algorithm import get_display
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT/'source-assets/dessert-menu'
OUT = ROOT/'output/pdf'
TMP = ROOT/'tmp/pdfs'
OUT.mkdir(exist_ok=True, parents=True)
TMP.mkdir(exist_ok=True, parents=True)
source = pymupdf.open(ASSETS/'Original_Dessert_Menu.pdf')
W, H = 540, 1635
# Sample the reference PDF's actual paper and ink, preserving its palette.
sample = source[0].get_pixmap(matrix=pymupdf.Matrix(1,1))
paper = tuple(v/255 for v in sample.pixel(10,10))
INK = '#30200f'
OLIVE = '#85886b'
pdfmetrics.registerFont(TTFont('Amiri', str(ASSETS/'Amiri-Regular.ttf')))
pdfmetrics.registerFont(TTFont('AmiriBold', str(ASSETS/'Amiri-Bold.ttf')))
pdfmetrics.registerFont(TTFont('English', 'C:/Windows/Fonts/times.ttf'))

def shape(s):
    return get_display(arabic_reshaper.reshape(s))

buf = BytesIO()
c = canvas.Canvas(buf, pagesize=(W,H))

def arabic(s,x,y,size=21,font='AmiriBold',align='right',color=INK):
    c.setFillColor(HexColor(color));c.setFont(font,size)
    getattr(c, {'right':'drawRightString','center':'drawCentredString'}[align])(x,H-y,shape(s))

def heading(ar,en,y):
    arabic(ar,488,y,22,'Amiri',color='#4d4d40')
    c.setFont('English',16);c.setFillColor(HexColor('#4d4d40'))
    c.drawRightString(488,H-y-22,en)
    c.setStrokeColor(HexColor('#d4d4be'));c.setLineWidth(1.5)
    c.line(501,H-y+19,501,H-y-25)

# Replace only the tiny original leader dots, leaving names and prices intact.
price_spans=[s for b in source[0].get_text('dict')['blocks'] for l in b.get('lines',[]) for s in l['spans'] if s['text'].strip().isdigit()]
# Currency stays physically to the left of each original price.
for price in price_spans:
    x,y=price['origin']
    c.setFont('Amiri',9);c.setFillColor(HexColor(INK))
    c.drawRightString(x-4,H-y,shape('د.ل'))

for drawing in source[0].get_drawings():
    r=drawing['rect']
    if 0<r.width<1 and 0<r.height<1:
        c.setFillColorRGB(*paper)
        c.rect(r.x0-.15,H-r.y1-.15,r.width+.3,r.height+.3,fill=1,stroke=0)
        nearest=min(price_spans,key=lambda s: abs(s['origin'][1]-r.y0)*10+abs(s['bbox'][2]-r.x0))
        c.setFillColor(HexColor('#978b77'))
        # All leaders sit just above the text baseline, like a full stop.
        c.circle((r.x0+r.x1)/2,H-nearest['origin'][1]+.6,.55,fill=1,stroke=0)

heading('كلاسيكيات','CLASSICS',211)
c.setStrokeColor(HexColor(OLIVE));c.setLineWidth(.5)
c.line(48,H-847,492,H-847)
heading('كيك','CAKES',884)

def item(index,name,price,cx,top,width=140,height=100,size=17,prefix=None):
    atlas=Image.open(ASSETS/'cakes-cartoon-atlas.png')
    # Read alpha bounds per atlas cell; PDF clipping preserves the original pixels.
    cellmap={0:(1,0),1:(2,0),2:(0,0),3:(1,1),4:(0,1),5:(2,2),6:(1,2),7:(0,2),8:(2,1)}
    col,row=cellmap[index];cw,ch=atlas.width//3,atlas.height//3
    cell=(col*cw,row*ch,(col+1)*cw,(row+1)*ch)
    bounds=atlas.getchannel('A').crop(cell).point(lambda v:255 if v>128 else 0).getbbox()
    x0,y0,x1,y1=bounds;x0+=cell[0];x1+=cell[0];y0+=cell[1];y1+=cell[1]
    ratio=min(width*.80/(x1-x0),height*.82/(y1-y0))
    bottom=top+height-6
    left=cx-(x1-x0)*ratio/2-x0*ratio
    image_top=bottom-y1*ratio
    c.saveState()
    clip=c.beginPath();clip.rect(left+cell[0]*ratio,H-image_top-cell[3]*ratio,cw*ratio,ch*ratio)
    c.clipPath(clip,stroke=0,fill=0)
    c.drawImage(ImageReader(atlas),left,H-image_top-atlas.height*ratio,width=atlas.width*ratio,height=atlas.height*ratio,mask='auto')
    c.restoreState()
    baseline=top+height+21
    # Center each complete name and its price on separate lines.
    while pdfmetrics.stringWidth(shape(name),'AmiriBold',size)>147:
        size-=.25
    arabic(name,cx,baseline,size,align='center')
    currency=shape('د.ل')
    currency_width=pdfmetrics.stringWidth(currency,'Amiri',10)
    price_width=pdfmetrics.stringWidth(str(price),'Amiri',16)
    start=cx-(currency_width+5+price_width)/2
    c.setFillColor(HexColor(INK));c.setFont('Amiri',10)
    c.drawString(start,H-baseline-24,currency)
    c.setFont('Amiri',16)
    c.drawString(start+currency_width+5,H-baseline-24,str(price))

# Three columns, aligned product baselines and generous paper space, as in reference.
item(1,'دارك كيك',38,435,948)
item(0,'كيك ليمون وفراولة',35,270,948)
item(2,'كيك العسل الروسية',35,105,948)
item(8,'كوكيز كيك',30,435,1133)
item(3,'ميني كيك فراولة',24,270,1133)
item(4,'ميني كيك فستق',24,105,1133)
item(5,'ميني كيك فستق وفراولة',24,435,1318)
item(6,'ميني كيك فريرو',24,270,1318)
item(7,'ميني لندن كيك',25,105,1318)
c.showPage();c.save()
overlay=pymupdf.open(stream=buf.getvalue(),filetype='pdf')
doc=pymupdf.open();page=doc.new_page(width=W,height=H)
page.draw_rect(page.rect,color=None,fill=paper)
# Preserve all original products and extras at their original size and positions.
page.show_pdf_page(pymupdf.Rect(0,0,540,825),source,0,clip=pymupdf.Rect(0,0,540,825))
page.show_pdf_page(page.rect,overlay,0)
# Move the original footer to the end; the logo appears exactly once.
page.show_pdf_page(pymupdf.Rect(0,1505,540,1625),source,0,clip=pymupdf.Rect(0,840,540,960))
doc.set_metadata({'title':'DOLCE | Desserts & Cakes','author':'DOLCE SKY'})
pdf=OUT/'Dolce_Dessert_Menu.pdf'
doc.save(pdf,garbage=4,deflate=True)
for label,rect in [('upper',pymupdf.Rect(0,0,540,850)),('lower',pymupdf.Rect(0,830,540,1635))]:
    page.get_pixmap(matrix=pymupdf.Matrix(2,2),clip=rect).save(TMP/f'dessert-studio-grid-{label}.png')
print(pdf)
